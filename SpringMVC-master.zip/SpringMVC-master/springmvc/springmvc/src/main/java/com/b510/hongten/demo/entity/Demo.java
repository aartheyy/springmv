package com.b510.hongten.demo.entity;

/**
 * @author Hongten
 * @date Nov 19, 2017
 */
public class Demo {

	private String title;
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
}
